import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App.jsx";

//6. Make sure that the final website is styled like the example shown here:
//https://l1pp6.csb.app/

//HINT: You will need to study the classes in the styles.css file to appy styling.

ReactDOM.render( <App />, document.querySelector( "#root" ) );
